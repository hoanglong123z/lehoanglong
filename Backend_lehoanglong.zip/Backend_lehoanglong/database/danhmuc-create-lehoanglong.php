<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
    include("ketnoi-lehoanglong.php");
    $sql_pb_LHL = "SELECT * FROM `danhmuc_lhl` WHERE 1=1";
    $res_pb_LHL = $conn_LHL->query($sql_pb_LHL);
    // => hiển thị trong điều khiển select
    // thực hiện thêm dữ liệu 
    $error_message_LHL ="";
    if(isset($_POST["btnsubmit_LHL"])){
        //lấy dữ liệu trên form
        $SPID_LHL = $_POST["SPID_LHL"];
        $TENSP_LHL = $_POST["TENSP_LHL"];
        $SOLUONG_LHL = $_POST["SOLUONG_LHL"];
        $GIAMUA_LHL = $_POST["GIAMUA_LHL"];
        $GIABAN_LHL = $_POST["GIABAN_LHL"];
        $TRANGTHAI_LHL = $_POST["TRANGTHAI_LHL"];
        $MADM = $_POST["MADM"];
        //kiểm tra khóa chính không được trùng
        $sql_check_LHL = "SELECT SPID_LHL FROM `sanpham_lhl` WHERE SPID_LHL = 'SPID_LHL' ";
        $res_check_LHL = $conn_LHL->query($sql_check_LHL);
        if($res_check_LHL->num_rows>0){
            $error_message_LHL="lỗi trùng khóa chính";
        }
        $sql_insert_LHL = "INSERT INTO `danhmuc_lhl` (`MADM_LHL`, `TENDM_LHL`, `TRANGTHAI_LHL`)";
        $sql_insert_LHL.="VALUES ('$MADM_LHL','$TENDM_LHL','$TRANGTHAI_LHL');";
        if($conn_LHL->query($sql_insert_LHL)){
            header("Location: danhmuc-list-lehoanglong.php"); 
        }else{
            $error_message_LHL="Lỗi thêm mới". mysqli_error($conn_LHL);
        }
    }
    ?>
<section class="container">
    <h1>Thêm mới thông tin sản phẩm</h1>
    <form name="frm_LHL" method="post" action="">
        <table border="1" width="100%" cellspacing="5" cellpadding="5">
            <tbody>
                <tr>
                    <td>Mã</td>
                    <td>
                        <input type="text" name="SPID_LHL" id="SPID_LHL">
                    </td>
                </tr>
                <tr>
                    <td>Tên</td>
                    <td>
                        <input type="text" name="TENSP_LHL" id="TENSP_LHL">
                    </td>
                </tr>
                <tr>
                    <td>Số lượng</td>
                    <td>
                        <input type="text" name="SOLUONG_LHL" id="SOLUONG_LHL">
                    </td>
                </tr>
                <tr>
                    <td>giá mua</td>
                    <td>
                        <input type="text" name="GIAMUA_LHL" id="GIAMUA_LHL">
                    </td>
                </tr>
                <tr>
                    <td>giá bán</td>
                    <td>
                        <input type="text" name="GIABAN_LHL" id="GIABAN_LHL">
                    </td>
                </tr>
                <tr>
                    <td>Trạng thái</td>
                    <td>
                        <select name="TRANGTHAI_LHL" >
                            <option value="1" selected>Hoạt động</option>
                            <option value="0" selected>Không hoạt động</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Danh mục</td>
                    <td>
                        <select name="MADM_LHL" id="MADM_LHL">
                            <?php
                                while($row = $res_pb_LHL->fetch_array()):        
                            ?>
                            <option value="<?php echo $row["MADM_LHL"]?>">
                                <?php echo $row["TENDM_LHL"]?>
                            </option>
                            <?php
                                endwhile;
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Thêm" name="btnSubmit_LHL">
                        <input type="reset" value="Làm lại" name="btnReset_LHL">
                    </td>
                </tr>
            </tbody>
        </table>    
        <div>
            <?php echo $error_message_LHL;?>
        </div>
    </form>
    <a href="danhmuc-list-lehoanglong.php">Danh mục sản phẩm</a>
</section>
</body>
</html>
