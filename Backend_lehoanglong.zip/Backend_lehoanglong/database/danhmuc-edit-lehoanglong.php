<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm mới thông tin sản phẩm</title>
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
    <?php
        include("ketnoi-lehoanglong.php");
        //đọc dữ liệu cần sửa
        if(isset($_GET["SPID_lhl"])){
            //lấy mã sản phẩm cần sửa
            $SPID_LHL= $_GET["SPID_lhl"];
            //tạo truy vấn đọc dữ liệu từ bảng sản phẩm
            $sql_edit_LHL= "SELECT * FROM `sanpham_lhl` WHERE SPID_LHL='$SPID_LHL'";
            // thực thi câu lệnh truy vấn
            $result_edit_LHL = $conn_LHL->query($sql_edit_LHL);
            //đọc bản ghi từ kết quả
            $row_edit_LHL = $result_edit_LHL->fetch_array();
        }else{
            header("Location: danhmuc-list-lehoanglong.php");
        }
        //đọc dữ liệu phòng ban
        $sql_pb_LHL = "SELECT * FROM `danhmuc_lhl` WHERE 1=1";
        $res_pb_LHL = $conn_LHL->query($sql_pb_LHL);
        // => hiển thị trong điều khiển select
        // Thực hiện thêm dữ liệu
        $error_message_LHL ="";
        if(isset($_POST["btnSubmit_LHL"])){
            // lấy dữ liệu trên form
            $SPID_LHL = $_POST["SPID_LHL"];
            $TENSP_LHL = $_POST["TENSP_LHL"];
            $SOLUONG_LHL = $_POST["SOLUONG_LHL"];
            $GIAMUA_LHL = $_POST["GIAMUA_LHL"];
            $GIABAN_LHL = $_POST["GIABAN_LHL"];
            $TRANGTHAI_LHL = $_POST["TRANGTHAI_LHL"];
            $MADM = $_POST["MADM"];
            $sql_update_LHL= "UPDATE `sanpham_lhl` SET";
            $sql_update_LHL.="SPID_LHL='$SPID_LHL',";
            $sql_update_LHL.="TENSP_LHL='$TENSP_LHL',";
            $sql_update_LHL.="SOLUONG_LHL='$SOLUONG_LHL',";
            $sql_update_LHL.="GIAMUA_LHL='$GIAMUA_LHL',";
            $sql_update_LHL.="GIABAN_LHL='$GIABAN_LHL'";
            $sql_update_LHL.="TRANGTHAI_LHL='$TRANGTHAI_LHL'";
            $sql_update_LHL.="MADM='$MADM'";
            $sql_update_LHL.=" WHERE SPID_LHL='$SPID_LHL'";
            if($conn_LHL->query($sql_update_LHL)){
                header("Location: danhmuc-list-lehoanglong.php"); 
            }else{
                $error_message_LHL="Lỗi sửa dữ liệu". mysqli_error($conn_LHL);
            }
        }
    ?>
    <section class="container">
        <h1>Thêm mới thông tin sản phẩm</h1>
        <form name="frm_LHL" method="post" action="">
            <table border="1" width="100%" cellspacing="5" cellpadding="5">
                <tbody>
                    <tr>
                        <td>Mã</td>
                        <td>
                            <input type="text" name="SPID_LHL" id="SPID_LHL" readonly
                                value="<?php echo  $row_edit_LHL["SPID_LHL"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Tên</td>
                        <td>
                            <input type="text" name="TENSP_LHL" id="TENSP_LHL"
                                value="<?php echo  $row_edit_LHL["TENSP_LHL"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Số lượng</td>
                        <td>
                            <input type="text" name="SOLUONG_LHL" id="SOLUONG_LHL"
                                value="<?php echo  $row_edit_LHL["SOLUONG_LHL"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>giá mua</td>
                        <td>
                        <input type="text" name="GIAMUA_LHL" id="GIAMUA_LHL"
                                value="<?php echo  $row_edit_LHL["GIAMUA_LHL"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>giá bán</td>
                        <td>
                        <input type="text" name="GIABAN_LHL" id="GIABAN_LHL"
                                value="<?php echo  $row_edit_LHL["GIABAN_LHL"]?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Trạng thái</td>
                        <td>
                            <select name="TRANGTHAI_LHL" >
                                <option value="1" <?php if($row_edit_LHL["TRANGTHAI_LHL"]==1){echo "selected";}?>>Hoạt động</option>
                                <option value="0" <?php if($row_edit_LHL["TRANGTHAI_LHL"]==0){echo "selected";}?>>Không hoạt động</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Danh mục </td>
                        <td>
                            <select name="MADM_LHL" id="MADM_LHL">
                                <?php
                                    while($row = $res_pb_LHL->fetch_array()):        
                                ?>
                                <option value="<?php echo $row["MADM_LHL"]?>"
                                <?php
                                    if($row["MADM_LHL"]==$row_edit_LHL["MADM_LHL"]){
                                        echo "selected";
                                    }
                                ?>
                                >
                                    <?php echo $row["TENDM_LHL"]?>
                                </option>
                                <?php
                                    endwhile;
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" value="Thêm" name="btnSubmit_LHL">
                            <input type="reset" value="Làm lại" name="btnReset_LHL">
                        </td>
                    </tr>
                </tbody>
            </table>    
            <div>
                <?php echo $error_message_LHL;?>
            </div>
        </form>
        <a href="danhmuc-list-lehoanglong.php">Danh sách sản phẩm</a>
    </section>
</body>
</html>