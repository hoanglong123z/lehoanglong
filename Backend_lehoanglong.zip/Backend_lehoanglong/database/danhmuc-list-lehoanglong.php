<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DANH SÁCH SẢN PHẨM - Lê Hoàng Long</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <?php
    //đọc dữ liệu và hiển thị
    //1. kết nối 
    include("ketnoi-lehoanglong.php");
    //2. tạo truy vấn đọc dữ liệu từ bảng
    $sql_LHL = "SELECT * FROM `sanpham_lhl` WHERE 1=1";
    //3. thực thi câu lệnh truy vấn
    $result_LHL = $conn_LHL->query($sql_LHL);
    //4. duyệt và hiển thị -> tbody

    ?>
    <section>
        <h1> DANH SÁCH SẢN PHẨM - LÊ HOÀNG LONG</h1>
        <hr/>
        <table width="100%" border="1px">
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Số lượng</th>
                    <th>Giá mua</th>
                    <th>Giá bán</th>
                    <th>Trạng thái</th>
                    <th>Danh mục</th>
                    <th>Chức năng</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if($result_LHL->num_rows>0){
                    $stt=0;
                    while($row_LHL=$result_LHL->fetch_array()):
                        $stt++;
                ?>
                <tr>
                    <td><?php echo $stt; ?></td>
                    <td><?php echo $row_LHL["SPID_LHL"]; ?></td>
                    <td><?php echo $row_LHL["TENSP_LHL"]; ?></td>
                    <td><?php echo $row_LHL["SOLUONG_LHL"]; ?></td>
                    <td><?php echo $row_LHL["GIAMUA_LHL"]; ?></td>
                    <td><?php echo $row_LHL["GIABAN_LHL"]; ?></td>
                    <td><?php echo $row_LHL["TRANGTHAI_LHL"]; ?></td>
                    <td><?php echo $row_LHL["MADM"]; ?></td>
                    <td>
                        <a href="danhmuc-edit-lehoanglong.php?SPID_LHL=<?php echo $row_LHL["SPID_LHL"];?>">
                            Sửa
                        </a>

                        <a href="danhmuc-list-lehoanglong.php?SPID_LHL=<?php echo $row_LHL["SPID_LHL"];?>"
                           onclick="if(confirm('Bạn có muốn xóa không')){return true;}else{return false;}">
                           Xóa
                        </a>
                    </td>
                </tr>
            <?php
                endwhile;   
                    }else{
            ?>
            <tr>
                <td colspan="9">chưa có dữ liệu </td>
            </tr>
            <?php
                    };
            ?>
        </tbody>
        </table>
    </section>

    <?php
    //xử lý với chức năng xóa
    if(isset($_GET["SPID_LHL"])){
        //thực hiện xóa sản phẩm theo SPID_LHL
        $SPID_LHL = $_GET["SPID_LHL"];
        //tạo truy vấn xóa
        $sql_delete_LHL = "DELETE FROM `danhmuc_lhl` WHERE SPID_LHL='$SPID_LHL'";
        //thực thi truy vấn
        if($conn_LHL->query($sql_delete_LHL)){
            header("Location:danhmuc-list-lehoanglong.php");
        }else{
            echo "<script> alert('lỗi xóa'); </script>";
        }
    }
?>                            
</body>
</html>