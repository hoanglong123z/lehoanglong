<?php
     $conn_LHL = new mysqli("localhost","root","","database/csdl-lehoanglong.sql");
     if(!$conn_LHL){
        echo "<h2> Lỗi: ". mysqli_error($conn_LHL). "</h2>";
     }else{
        echo "<h2>Xin chào ,Lê Hoàng Long-2210900037 </h2>";
     }
     ?>