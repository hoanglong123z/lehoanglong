var _0x1f55=["\x76\x61\x6C\x75\x65","\x75\x73\x65\x72\x6E\x61\x6D\x65","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64","\x70\x61\x73\x73\x77\x6F\x72\x64\x2D\x66\x69\x65\x6C\x64","\x61\x64\x6D\x69\x6E","\x31\x32\x33\x34\x35\x36","","\x58\x69\x6E\x20\x63\x68\xE0\x6F\x20\x56\xF5\x20\x54\x72\u01B0\u1EDD\x6E\x67","\x73\x75\x63\x63\x65\x73\x73","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x64\x6F\x63\x2F\x69\x6E\x64\x65\x78\x2E\x68\x74\x6D\x6C","\x42\u1EA1\x6E\x20\x63\x68\u01B0\x61\x20\u0111\x69\u1EC1\x6E\x20\u0111\u1EA7\x79\x20\u0111\u1EE7\x20\x74\x68\xF4\x6E\x67\x20\x74\x69\x6E\x20\u0111\u0103\x6E\x67\x20\x6E\x68\u1EAD\x70\x2E\x2E\x2E","\x65\x72\x72\x6F\x72","\x54\x68\u1EED\x20\x6C\u1EA1\x69","\x42\u1EA1\x6E\x20\x63\x68\u01B0\x61\x20\x6E\x68\u1EAD\x70\x20\x6D\u1EAD\x74\x20\x6B\x68\u1EA9\x75\x2E\x2E\x2E","\x77\x61\x72\x6E\x69\x6E\x67","\x54\xE0\x69\x20\x6B\x68\x6F\u1EA3\x6E\x20\u0111\x61\x6E\x67\x20\u0111\u1EC3\x20\x74\x72\u1ED1\x6E\x67\x2E\x2E\x2E","\x4D\u1EAD\x74\x20\x6B\x68\u1EA9\x75\x20\u0111\x61\x6E\x67\x20\u0111\u1EC3\x20\x74\x72\u1ED1\x6E\x67\x2E\x2E\x2E","\x53\x61\x69\x20\x74\x68\xF4\x6E\x67\x20\x74\x69\x6E\x20\u0111\u0103\x6E\x67\x20\x6E\x68\u1EAD\x70\x20\x68\xE3\x79\x20\x6B\x69\u1EC3\x6D\x20\x74\x72\x61\x20\x6C\u1EA1\x69\x2E\x2E\x2E","\x74\x65\x73\x74","\x42\u1EA1\x6E\x20\x76\x75\x69\x20\x6C\xF2\x6E\x67\x20\x6E\x68\u1EAD\x70\x20\u0111\xFA\x6E\x67\x20\u0111\u1ECB\x6E\x68\x20\x64\u1EA1\x6E\x67\x20\x65\x6D\x61\x69\x6C\x2E\x2E\x2E","\x66\x6F\x63\x75\x73","\x43\x68\xFA\x6E\x67\x20\x74\xF4\x69\x20\x76\u1EEB\x61\x20\x67\u1EED\x69\x20\x63\x68\x6F\x20\x62\u1EA1\x6E\x20\x65\x6D\x61\x69\x6C\x20\x68\u01B0\u1EDB\x6E\x67\x20\x64\u1EAB\x6E\x20\u0111\u1EB7\x74\x20\x6C\u1EA1\x69\x20\x6D\u1EAD\x74\x20\x6B\x68\u1EA9\x75\x20\x76\xE0\x6F\x20\u0111\u1ECB\x61\x20\x63\x68\u1EC9\x20\x63\x68\x6F\x20\x62\u1EA1\x6E","\u0110\xF3\x6E\x67","\x23"];function validate(){var _0x9903x2=document[_0x1f55[2]](_0x1f55[1])[_0x1f55[0]];var _0x9903x3=document[_0x1f55[2]](_0x1f55[3])[_0x1f55[0]];if(_0x9903x2== _0x1f55[4]&& _0x9903x3== _0x1f55[5]){swal({title:_0x1f55[6],text:_0x1f55[7],icon:_0x1f55[8],close:true,button:false});window[_0x1f55[9]]= _0x1f55[10];return true};if(_0x9903x2== _0x1f55[6]&& _0x9903x3== _0x1f55[6]){swal({title:_0x1f55[6],text:_0x1f55[11],icon:_0x1f55[12],close:true,button:_0x1f55[13]});return false};if(_0x9903x2== _0x1f55[4]&& _0x9903x3== _0x1f55[6]){swal({title:_0x1f55[6],text:_0x1f55[14],icon:_0x1f55[15],close:true,button:_0x1f55[13]});return false};if(_0x9903x2== null|| _0x9903x2== _0x1f55[6]){swal({title:_0x1f55[6],text:_0x1f55[16],icon:_0x1f55[15],close:true,button:_0x1f55[13]});return false};if(_0x9903x3== null|| _0x9903x3== _0x1f55[6]){swal({title:_0x1f55[6],text:_0x1f55[17],icon:_0x1f55[15],close:true,button:_0x1f55[13]});return false}else {swal({title:_0x1f55[6],text:_0x1f55[18],icon:_0x1f55[12],close:true,button:_0x1f55[13]});return true}}function RegexEmail(_0x9903x5){var _0x9903x6=document[_0x1f55[2]](_0x9903x5)[_0x1f55[0]];var _0x9903x7=/^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;var _0x9903x8=_0x9903x7[_0x1f55[19]](_0x9903x6);if(!_0x9903x8){swal({title:_0x1f55[6],text:_0x1f55[20],icon:_0x1f55[12],close:true,button:_0x1f55[13]});_0x9903x5[_0x1f55[21]]}else {swal({title:_0x1f55[6],text:_0x1f55[22],icon:_0x1f55[8],close:true,button:_0x1f55[23]});_0x9903x5[_0x1f55[21]];window[_0x1f55[9]]= _0x1f55[24]}}
function validate() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password-field").value;
    //Đặt 1 Admin ảo để đăng nhập quản trị
    if (username == "admin" && password == "123456") {
        swal({
            title: "",
            text: "Xin chào Võ Trường",
            icon: "success",
            close: true,
            button: false,
          });
        window.location = "doc/index.html";
        return true;
       
    }
    //Nếu không nhập gì mà nhấn đăng nhập thì sẽ báo lỗi
    if (username == "" && password == "") {
        swal({
            title: "",
            text: "Bạn chưa điền đầy đủ thông tin đăng nhập...",
            icon: "error",
            close: true,
            button: "Thử lại",
          });
         
        return false;
       
    }
    //Nếu không nhập mật khẩu mà đúng tài khoản 
    if (username == "admin" && password == "") {
        swal({
            title: "",
            text: "Bạn chưa nhập mật khẩu...",
            icon: "warning",
            close: true,
            button: "Thử lại",
          });
        return false;
    }
    //Nếu không nhập tài khoản sẽ báo lỗi
    if (username == null || username == "") {
        swal({
            title: "",
            text: "Tài khoản đang để trống...",
            icon: "warning",
            close: true,
            button: "Thử lại",
          });
        return false;
    }
    //Nếu không nhập mật khẩu sẽ báo lỗi
    if (password == null || password == "") {
        swal({
            title: "",
            text: "Mật khẩu đang để trống...",
            icon: "warning",
            close: true,
            button: "Thử lại",
          });
        return false;
    }
    //Nếu trống toàn bộ thì báo lỗi
    else {
        swal({
            title: "",
            text: "Sai thông tin đăng nhập hãy kiểm tra lại...",
            icon: "error",
            close: true,
            button: "Thử lại",
          });
        return true;
    };
}

/*  PHẦN NỘI DUNG KHÔI PHỤC MẬT KHẨU   */

/* =========================================== */
/* =========================================== */
//  function validate() {
//      var email = document.getElementById("email").value;
//     if (email == null || email == "") {
//        swal("Bạn Chưa Nhập Email", "Vui Lòng Kiểm Tra", "warning");
//        return false;
//    }
//}
function RegexEmail(emailInputBox) {
    var emailStr = document.getElementById(emailInputBox).value;
    var emailRegexStr = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    var isvalid = emailRegexStr.test(emailStr);
    if (!isvalid) {
        swal({
            title: "",
            text: "Bạn vui lòng nhập đúng định dạng email...",
            icon: "error",
            close: true,
            button: "Thử lại",
          });
        
        emailInputBox.focus;
    } else {
        swal({
            title: "",
            text: "Chúng tôi vừa gửi cho bạn email hướng dẫn đặt lại mật khẩu vào địa chỉ cho bạn",
            icon: "success",
            close: true,
            button: "Đóng",
          });
        emailInputBox.focus;
        window.location = "#";

    }
}